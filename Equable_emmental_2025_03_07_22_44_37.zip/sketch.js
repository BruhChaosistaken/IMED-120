let cwidth = 300
let cheight = 200

function setup() {
  createCanvas(cwidth, cheight);
  
  let keybutton;
  keybutton = createButton("")
  keybutton.position(0,0)
  keybutton.size(cwidth/5,cheight)
  keybutton.style('background:white')
  keybutton.mousePressed(Key)
  
    let keybutton2;
  keybutton2 = createButton("")
  keybutton2.position(cwidth/7,0)
  keybutton2.size(cwidth/7,cheight/2)
  keybutton2.style('background:black')
  keybutton2.mousePressed(Key2)
  
    let keybutton3;
  keybutton3 = createButton("")
  keybutton3.position(cwidth/7 * 2,0)
  keybutton3.size(cwidth/5,cheight)
  keybutton3.style('background:white')
  keybutton3.mousePressed(Key3)

    let keybutton4;
  keybutton4 = createButton("")
  keybutton4.position(cwidth/7 * 3,0)
  keybutton4.size(cwidth/7,cheight/2)
  keybutton4.style('background:black')
  keybutton4.mousePressed(Key4)
  
    let keybutton5;
  keybutton5 = createButton("")
  keybutton5.position(cwidth/7 * 4,0)
  keybutton5.size(cwidth/5,cheight)
  keybutton5.style('background:white')
  keybutton5.mousePressed(Key5)
  
    let keybutton6;
  keybutton6 = createButton("")
  keybutton6.position(cwidth/7 * 5,0)
  keybutton6.size(cwidth/7,cheight/2)
  keybutton6.style('background:black')
  keybutton6.mousePressed(Key6)
  
      let keybutton7;
  keybutton7 = createButton("")
  keybutton7.position(cwidth/7 * 6,0)
  keybutton7.size(cwidth/7,cheight)
  keybutton7.style('background:white')
  keybutton7.mousePressed(Key7)

}

function Key() {
  
}

function Key2() {
  
}

function Key3() {
  
}

function Key4() {
  
}

function Key5() {
  
}

function Key6() {
  
}

function Key7() {
  
}
function draw() {
  background('white');
  
}