function setup() {
  
  createCanvas(600, 400);
  background(250);
  textSize(32);
  fill(0);
  textAlign(CENTER)
  textStyle(BOLDITALIC)
  textFont("Times New Roman")
  
  text('Harrisburg University', 300,100)
  
  textSize(14)
  fill(100)
  textAlign(LEFT)

  text("My name is Qasim A. Williams, I am 19 years old and am majoring in interactive media. I specifically chose HU and interactive media as my major because I love video games and want to get the excitement of working with other people like that. But chose HU since I had got accepted into it knowing they have programs for my dream, so by taking these classes I am willing and prideful to learn what goes into the coding, art, animation, music production, and overall flow of creating video games.", 100,150, 400,800)
  
}


function draw() {

  
}